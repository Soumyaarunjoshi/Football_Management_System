# Football-management
Web project
use mysql and apache server
create a database named management and import management.sql file and run the project
